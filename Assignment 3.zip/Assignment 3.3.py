import random


# Read the file, omitting meanings and removing trailing '.' from words
def file_into_list(file_name):
    with open(file_name, 'r') as f:
        dictionary_li = []
        while True:
            lines = f.readline()
            if lines == "":
                break
            lines = lines.split(" :")
            if 3 <= len(lines[0]) <= 10:
                if lines[0][-1] == '.':
                    dictionary_li.append(lines[0][:-1])
                else:
                    dictionary_li.append(lines[0])
    return dictionary_li


# Validate and get user input
def input_error_check(com_word_len):
    while True:
        try:
            user_input = input(f"{com_word_len}글자의 단어와 글자수를 입력하세요: ").strip().split()
            user_word, user_word_len = user_input[0], int(user_input[1])
            return user_word, user_word_len
        except (IndexError, ValueError):
            print("Wrong format. Please enter a valid word and length.")


# Generate a new word for the computer
def new_com_word():
    global c_word
    global c_word_len
    global u_word
    global mark

    # Find a word that matches the user's word and hasn't been used
    for new_w in dictionary_list:
        if new_w[0] == u_word[-1] and len(new_w) == u_word_len:
            if new_w in word_list:
                continue
            else:
                c_word = new_w
                break

    # Set a random length for the new computer word
    for new_w in dictionary_list:
        number = random.randint(3, 10)
        if c_word[-1] == new_w[0] and c_word_len == len(new_w):
            c_word_len = number
            break


# Initialize the game
dictionary_list = file_into_list('dict_test.TXT')
# Initialize apple for easier testing
c_word = "apple"
c_word_len = len(c_word)
word_list = [c_word]
mark = 0

# Initialize the game
for count in range(1, 11):
    print(f"{count} round")
    print(f"컴퓨터: {c_word} {c_word_len}")

    u_word, u_word_len = input_error_check(c_word_len)

    if 3 <= u_word_len <= 10:
        if len(u_word) == c_word_len:
            # If the word already comes out
            if u_word in word_list:
                mark -= 1
                print(f"이미 나온 단어입니다(-1). 현재 점수 {mark}점")
            # If the word first character is the same as last character from computer
            elif c_word[-1] == u_word[0]:
                # If the word is in the dictionary
                if u_word in dictionary_list:
                    word_list.append(u_word)
                    mark += 1
                    print(f"1점 획득. 현재 점수 {mark}점")
                else:
                    print(f"Dictionary 에서 없는 단어입니다(-1). 현재 점수 {mark}점")
            else:
                mark -= 1
                print(f"끝말잇기가 안됩니다(-1). 현재 점수 {mark}점")

            count += 1
        # If the word count is the same as the desired word count from computer
        else:
            mark -= 1
            print(f"단어 수와 일치하지 않습니다(-1). 현재 점수 {mark}점")
            count += 1

        new_com_word()

    else:
        # No mark deduction for incorrect word length
        # No change of word too
        print(f"단어는 3~10자 사이여야 합니다.")

    print()

print(f"게임 종료. 최종 점수: {mark}점")
