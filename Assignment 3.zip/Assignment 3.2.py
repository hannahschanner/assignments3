import random
from time import time


# Read the file and create a list with words
# Omitted the meaning part since it is not needed
def random_lines(length):
    practice = 1
    line_num = set()

    while practice <= 5:
        number = random.randint(1, length)
        if number not in line_num:
            line_num.add(number)
            practice += 1

    return line_num

# Check if the words are match
def matching(com, user):
    com_len = len(com)
    user_len = len(user)

    if user_len < com_len:
        while user_len < com_len:
            user.append("\0")
            user_len += 1

        wrong_index = []
        for index, character in enumerate(user):
            if character == com[index]:
                wrong_index.append(0)
            else:
                wrong_index.append(1)
            if index > len(com) - 1:
                break

    else:
        exceeded = user_len - com_len

        wrong_index = []
        try:
            for index, character in enumerate(user):
                if character == com[index]:
                    wrong_index.append(0)
                else:
                    wrong_index.append(1)
                if index > len(com) - 1:
                    break
        except IndexError:
            for number in range(exceeded):
                wrong_index.append(1)

    printing_position(wrong_index)
    return wrong_index.count(0)
    # print(com_len)
    # print(user_len)
    # print(len(user))
    # print(len(wrong_index))

# Print the error place depending on correct words
def printing_position(wrong):
    if sum(wrong) == 0:
        return
    else:
        for flag in wrong:
            if flag == 1:
                print("^", end="")
            else:
                print(" ", end="")
        print()


# Read random lines from the file and append it into list
with open("littleprince.txt", 'r') as fp:
    lines = fp.readlines()
    line_numbers = random_lines(len(lines))

    selected_lines = []

    for i in line_numbers:
        selected_lines.append(lines[i - 1].strip())

# Main Program
for line in selected_lines:
    print(line)
    showed_list = list(map(str, line))
    start_time = time()
    user_words = input()
    spend_time = time() - start_time

    input_list = list(map(str, user_words))
    # Calculate the speed depending on the correct words
    correct = matching(showed_list, input_list)
    speed = 60 * correct / spend_time
    print(f"{int(speed)} strokes/minute ")
