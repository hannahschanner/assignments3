def print_country_data(titles, lines):
    title_data = titles.split(',')
    chosen_data = lines.split(',')

    # Print the title row and chosen data row with alignment
    for ite in range(len(title_data)):
        print(f"{title_data[ite].strip()}:\t{chosen_data[ite].strip():40s}")
    print()  # Move to the next line


search_query = input("Enter the Country name:")

found_lines = {}  # Dictionary to store the last line for each unique name

with open('owid-covid-data.csv', 'r') as file:
    title = file.readline()  # Add the title as the first line
    for line in file:
        if search_query in line:
            found_name = line.split(',')[2]  # Assuming the name is in the third column
            found_lines[found_name] = line

if len(found_lines) > 1:
    # Display options for the user to choose
    print("Unique options found for the search query:")
    options = list(found_lines.keys())
    for i, option in enumerate(options, start=1):
        print(f"{i}. {option}")

    # Ask the user to choose an option
    choice = input("Choose an option (1, 2, etc.): ")
    try:
        choice_index = int(choice) - 1
        if 0 <= choice_index < len(options):
            chosen_name = options[choice_index]
            print(f"User chose {chosen_name}:")
            chosen_line = found_lines[chosen_name]
            print_country_data(title, chosen_line)
        else:
            print("Invalid choice.")
    except ValueError:
        print("Invalid input. Please enter a valid choice.")
elif len(found_lines) == 1:
    chosen_name = list(found_lines.keys())[0]
    chosen_line = found_lines[chosen_name]
    print_country_data(title, chosen_line)
else:
    print("Not found")
