# Read the file and create a dictionary list with words and meanings
def file_into_list():
    global dictionary_list
    global f
    while True:
        lines = f.readline()
        if lines == "":
            break
        # Split the line into word and meaning
        lines = lines.split(" :")
        dictionary_list.append(lines[0])
        meaning = lines[1]
        # Remove the trailing newline character from the meaning
        lines[1] = meaning[:-1]
        dictionary_list.append(lines[1])


# Display word meanings, allowing the user to choose if there are multiple meanings
def output_dictionary():
    global dictionary_list
    global found_index
    global limit

    if len(found_index) > 1:
        print("Here is the words that has a part of the search word")
        print("Print the number you want to know")
        for key, value in enumerate(found_index):
            print(f"{key + 1}. {dictionary_list[found_index[key]]} ")

        # Print Not found when the input is wrong
        try:
            number = int(input("Number ? "))
            print(f"{dictionary_list[found_index[number - 1]]} : {dictionary_list[found_index[number - 1] + 1]}")
        except (ValueError,IndexError):
            print("Not found")

    elif len(found_index) == 1:
        print(f"{dictionary_list[found_index[0]]} : {dictionary_list[found_index[0] + 1]}")
    else:
        print("Not found")


f = open('dict_test.TXT', 'r')
dictionary_list = []
limit = 5  # You can limit the number of results when there's more than one match

file_into_list()
s_word = input("word? ")
while True:
    i = 0
    found_index = []
    while i < len(dictionary_list):
        if len(found_index) >= limit:
            break
        if s_word in dictionary_list[i]:
            found_index.append(i)
        i += 2
    output_dictionary()
    s_word = input("word? ")
